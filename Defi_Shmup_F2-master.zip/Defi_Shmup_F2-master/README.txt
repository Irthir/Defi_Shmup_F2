Lien du jeu Ready : https://ready.app.link/eSTUnlePz1

__________________________________________________________________________________________________________________________________________________________________________________

Les Sources : 

Pour les sprites des aliens :
ResourcesKenney's free assets Construct.net
kenney_spaceshooterextension

Pour le sprite du Joueur :
Skorpio ( http://opengameart.org/users/skorpio )

Pour le boss et les attaques ennemies :
These sprites are licensed under the CC BY 3.0 license: http://creativecommons.org/licenses/by/3.0/.
We require attribution to Gamedevtuts+, and a link to this post: http://gamedev.tutsplus.com/articles/news/enjoy-these-totally-free-space-based-shoot-em-up-sprites/,
from anyone that redistributes the artwork, but we do not require attribution if you use the art in your games (regardless of whether it is for commercial or personal use, or for a prototype or final product).

Pour les lasers et l'image de fond:
Tuto Space Chicken : https://unity3d.com/fr/learn/tutorials/s/space-chicken

Musique de Fond :
https://soundcloud.com/petterthesturgeon/anything1
Copyright/Attribution Notice: 
Feel free to use and share anywhere, but note me, if you using it :D

Musique du Boss :
Copyright/Attribution Notice: 
Music by Cleyton Kauffman - https://soundcloud.com/cleytonkauffman

Pour le son des lasers il s'agit de Laser_Boom déjà présent sur ReadyMaker.
Pour les sons des explosions ils s'agit d'Explosion1 et Explosion2 déjà présents sur ReadyMaker.
Pour le son des bonus il s'agit de Coin déjà présent sur ReadyMaker.


Tout provenant du site OpenGameArt.org, à l'exception des éléments provenant du tuto space chicken et des sprites des aliens provenant de Construct.net

__________________________________________________________________________________________________________________________________________________________________________________